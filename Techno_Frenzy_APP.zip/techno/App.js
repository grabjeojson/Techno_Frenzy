import * as React from 'react';
import { Text, View, StyleSheet,Button,Alert,SafeAreaView} from 'react-native';
import Constants from 'expo-constants';
import Modal from "react-native-modal";
import  {useState} from 'react';
import { TouchableOpacity } from 'react-native';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
       WELCOME TO SOLUTIONS FOR YOUR BUSINESS
      </Text>
      <Text style={styles.paragraph}>
       User Id: G-19887
      </Text>
      <Card>
        <AssetExample />
      </Card>
    </View>
  );
  
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 3,
  },
  paragraph: {
    margin: 12,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
