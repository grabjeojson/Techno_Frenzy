import * as React from 'react';
import { Text,Alert, View, StyleSheet, Image,TouchableOpacity,Button } from 'react-native';
import Modal from "react-native-modal";
import {Linking} from 'react-native';

import BackgroundFetch from "react-native-background-fetch";

export default function AssetExample() {

  callFun = () =>
  {
    Alert.alert(
       //This is title
      'Dear Techno Frenzy',
        //This is body text
      'Please select one support you need.',
      [
        {text:'No Thanks',style:'buttonText'},
        {text: 'Connect Direct Support Team', onPress:()=> this.callDashboard('G-19887')},
        {text: 'Call SDP', onPress:()=>{Linking.openURL('tel:7337376695');}}, 
      ],
      { cancelable: true },
      //on clicking out side, Alert will not dismiss
    );   
  }
callDashboard = (userId) =>
{
  alert("Please wait. Connecting our support team....... ");
  fetch('http://skssickoiripatty.in/technofrenzy/requestUpdate.php?userId='+userId, { method: 'POST' })
    .then(data => data.json()) // Parsing the data into a JavaScript object
    .then(json => this.connectSupport())
},
connectSupport=()=>{
  setTimeout(function () {
        console.log("Waited 10s");
    }, 1000000);
  alert('Requesting for support. Please wait.....');
  setTimeout(function () {
        console.log("Waited 10s");
    }, 1000000);
  // fetch('http://skssickoiripatty.in/technofrenzy/requestUpdate.php?userId=0', { method: 'POST' })
  //   .then(data => data.json()) // Parsing the data into a JavaScript object
  //   .then(json => alert(JSON.stringify(json[0].responseData.errorDesc))) 
}
 
  return (
    <View style={styles.container}>
      <Image style={styles.logo} source={require('../assets/logo.png')} />
      
      <TouchableOpacity activeOpacity = { .5 } onPress={ this.callFun }>
       <Image style={styles.help} source={require('../assets/HelpButton.png')} />
    </TouchableOpacity>
    <Text style={styles.paragraph}>
       Presented By: Techno Frenzy Team
      </Text>
    </View>
  );
}


// Simulate a long-running task (eg: HTTP request)
function doAction() { 
  let timeout = 5000;
  return new Promise(resolve => {
    setTimeout(() => {
      console.log('*** TIMEOUT ***');
      resolve();
    }, timeout);
  });
}

// Register your BackgroundFetch HeadlessTask

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
  },
  paragraph: {
    margin: 10,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 100,
    width: 300,
  },
  help: {
    height: 110,
    width: 300,
  },
  buttonText:{
    textAlign: 'center',
    padding: 20,
    color: 'red',
    backgroundColor: '#2196F3'
  },
});
