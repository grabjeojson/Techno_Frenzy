-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 22, 2022 at 04:29 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skssickoiripatt_technofrenzy`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `ip_address` varchar(45) CHARACTER SET utf8 NOT NULL DEFAULT '0',
  `user_agent` varchar(120) CHARACTER SET utf8 DEFAULT NULL,
  `last_activity` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `user_data` text CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('1191020cc78d27f1e400f45b88bccb40', '223.236.198.82', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 1661150919, 'a:4:{s:9:\"user_data\";s:0:\"\";s:11:\"msg_success\";s:0:\"\";s:15:\"admin_user_name\";s:5:\"admin\";s:12:\"user_account\";a:8:{s:7:\"user_id\";s:1:\"1\";s:9:\"user_name\";s:5:\"admin\";s:10:\"user_email\";s:15:\"admin@gmail.com\";s:9:\"user_type\";s:1:\"2\";s:7:\"role_id\";s:1:\"1\";s:10:\"first_name\";s:1:\"@\";s:9:\"last_name\";s:5:\"Admin\";s:15:\"user_privileges\";a:0:{}}}'),
('6e492a872b1531106f57b958b0fe8ba1', '49.207.216.61', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 1661161613, 'a:4:{s:9:\"user_data\";s:0:\"\";s:11:\"msg_success\";s:0:\"\";s:12:\"user_account\";a:8:{s:7:\"user_id\";s:1:\"1\";s:9:\"user_name\";s:5:\"admin\";s:10:\"user_email\";s:15:\"admin@gmail.com\";s:9:\"user_type\";s:1:\"2\";s:7:\"role_id\";s:1:\"1\";s:10:\"first_name\";s:1:\"@\";s:9:\"last_name\";s:5:\"Admin\";s:15:\"user_privileges\";a:0:{}}s:15:\"admin_user_name\";s:5:\"admin\";}'),
('894db3c8ebabdac648f79dff262f182c', '119.235.52.210', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.102 Safari/537.36', 1661154019, 'a:4:{s:9:\"user_data\";s:0:\"\";s:11:\"msg_success\";s:0:\"\";s:12:\"user_account\";a:8:{s:7:\"user_id\";s:1:\"1\";s:9:\"user_name\";s:5:\"admin\";s:10:\"user_email\";s:15:\"admin@gmail.com\";s:9:\"user_type\";s:1:\"2\";s:7:\"role_id\";s:1:\"1\";s:10:\"first_name\";s:1:\"@\";s:9:\"last_name\";s:5:\"Admin\";s:15:\"user_privileges\";a:0:{}}s:15:\"admin_user_name\";s:5:\"admin\";}');

-- --------------------------------------------------------

--
-- Table structure for table `duration`
--

CREATE TABLE `duration` (
  `duration_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `duration`
--

INSERT INTO `duration` (`duration_id`, `name`, `status`) VALUES
(1, 'Monthly', 1),
(2, 'Quarterly', 1),
(3, 'Half Yearly', 1),
(4, 'Yearly', 1);

-- --------------------------------------------------------

--
-- Table structure for table `manage_user_plan`
--

CREATE TABLE `manage_user_plan` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `plan_id` int(11) DEFAULT NULL,
  `duration_id` int(11) DEFAULT NULL,
  `admission_fees` varchar(255) DEFAULT NULL,
  `free_steam` int(11) DEFAULT NULL,
  `admission_date` varchar(255) DEFAULT NULL,
  `admiss_exp_date` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mst_employees`
--

CREATE TABLE `mst_employees` (
  `emp_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_employees`
--

INSERT INTO `mst_employees` (`emp_id`, `name`, `phone`, `email`, `status`) VALUES
(3, 'Sunil', '8605422781', 'sunilrpatil@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mst_global_settings`
--

CREATE TABLE `mst_global_settings` (
  `global_name_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mst_global_settings`
--

INSERT INTO `mst_global_settings` (`global_name_id`, `name`) VALUES
(1, 'site_email'),
(2, 'site_title'),
(3, 'contact_email'),
(4, 'date_format'),
(7, 'per_page_record'),
(8, 'facebook_link'),
(9, 'twitter_link'),
(11, 'google_link'),
(13, 'phone_no'),
(14, 'facebook_app_id'),
(15, 'pinterest_link'),
(16, 'zip_code'),
(17, 'address'),
(18, 'street'),
(19, 'city'),
(20, 'contact_us_message'),
(1, 'site_email'),
(2, 'site_title'),
(3, 'contact_email'),
(4, 'date_format'),
(7, 'per_page_record'),
(8, 'facebook_link'),
(9, 'twitter_link'),
(11, 'google_link'),
(13, 'phone_no'),
(14, 'facebook_app_id'),
(15, 'pinterest_link'),
(16, 'zip_code'),
(17, 'address'),
(18, 'street'),
(19, 'city'),
(20, 'contact_us_message'),
(1, 'site_email'),
(2, 'site_title'),
(3, 'contact_email'),
(4, 'date_format'),
(7, 'per_page_record'),
(8, 'facebook_link'),
(9, 'twitter_link'),
(11, 'google_link'),
(13, 'phone_no'),
(14, 'facebook_app_id'),
(15, 'pinterest_link'),
(16, 'zip_code'),
(17, 'address'),
(18, 'street'),
(19, 'city'),
(20, 'contact_us_message');

-- --------------------------------------------------------

--
-- Table structure for table `mst_privileges`
--

CREATE TABLE `mst_privileges` (
  `privileges_id` int(11) NOT NULL,
  `privilege_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mst_privileges`
--

INSERT INTO `mst_privileges` (`privileges_id`, `privilege_name`) VALUES
(1, 'Email Templates'),
(3, 'Manage CMS'),
(4, 'Contact Us Section'),
(5, 'User Section'),
(6, 'Newsletter Section'),
(7, 'FAQ Section'),
(8, 'Interests Section');

-- --------------------------------------------------------

--
-- Table structure for table `mst_role`
--

CREATE TABLE `mst_role` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mst_role`
--

INSERT INTO `mst_role` (`role_id`, `role_name`) VALUES
(1, 'Super Admin'),
(23, 'Sub Admin'),
(36, 'test123'),
(37, 'dssadsadsadas');

-- --------------------------------------------------------

--
-- Table structure for table `mst_users`
--

CREATE TABLE `mst_users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_email` varchar(250) NOT NULL,
  `user_password` varchar(150) NOT NULL,
  `profile_picture` varchar(20) DEFAULT NULL,
  `gender` varchar(100) NOT NULL,
  `user_type` enum('1','2') NOT NULL COMMENT '1=>Normal 2=>admin',
  `user_status` enum('0','1','2') NOT NULL COMMENT '0=>Inactive,1=>Active,2=>Blocked',
  `activation_code` varchar(20) DEFAULT NULL,
  `reset_password_code` varchar(20) NOT NULL,
  `email_verified` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=>No,1=>Yes',
  `last_login` datetime DEFAULT NULL,
  `fb_id` varchar(25) DEFAULT NULL,
  `mobile_no` varchar(25) DEFAULT NULL,
  `register_date` datetime NOT NULL,
  `user_county` int(11) DEFAULT NULL,
  `user_city` int(11) DEFAULT NULL,
  `user_birth_date` varchar(45) DEFAULT NULL,
  `first_name` varchar(150) DEFAULT NULL,
  `last_name` varchar(150) DEFAULT NULL,
  `zip_code` varchar(20) NOT NULL,
  `last_logout_time` datetime DEFAULT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mst_users`
--

INSERT INTO `mst_users` (`user_id`, `user_name`, `user_email`, `user_password`, `profile_picture`, `gender`, `user_type`, `user_status`, `activation_code`, `reset_password_code`, `email_verified`, `last_login`, `fb_id`, `mobile_no`, `register_date`, `user_county`, `user_city`, `user_birth_date`, `first_name`, `last_name`, `zip_code`, `last_logout_time`, `role_id`) VALUES
(1, 'admin', 'admin@gmail.com', 'MTIzNDU2', '731717764.jpg', '1', '2', '1', '1521457584', '', '1', NULL, NULL, NULL, '0000-00-00 00:00:00', NULL, NULL, NULL, '@', 'Admin', '', NULL, 1),
(2, 'testa', 'amaryelmar11@gmail.com', 'MTIzNDU2', '731717764.jpg', '1', '1', '1', 'sad21312323213', '', '1', NULL, NULL, '1111111111', '0000-00-00 00:00:00', NULL, NULL, NULL, 'Rohite', 'Patil', '', NULL, 1),
(3, '', 'tes@test1.com', 'MTIzNDU2', '1504869746.png', '', '1', '1', '1504676525', '', '1', NULL, NULL, NULL, '2017-09-06 11:12:05', NULL, NULL, NULL, 'rrrrrrwwwr', 'wwwweeee', '', NULL, 0),
(4, '', 'tes@test1w.com', 'MTIzNDU2', NULL, '1', '1', '1', '1504680476', '', '0', NULL, NULL, '1234567852', '2017-09-06 12:17:56', NULL, NULL, NULL, 'pawan', 'pawan', '', NULL, 0),
(5, '', 'tes@test11.com', 'MTIzNDU2', NULL, '1', '1', '1', '1504683410', '', '1', NULL, NULL, '1234567896', '2017-09-06 13:06:50', NULL, NULL, NULL, 'pawan', 'pawan', '', NULL, 0),
(6, '', 'tes@test1133.com', 'MTIzNDU2', NULL, '1', '1', '1', '1504868359', '', '1', NULL, NULL, '1234567856', '2017-09-08 16:29:19', NULL, NULL, '12-7-1991', 'pawanssd', 'pawansdsd', '', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_request`
--

CREATE TABLE `tbl_user_request` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `session_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 1,
  `response` text COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user_request`
--

INSERT INTO `tbl_user_request` (`id`, `user_id`, `name`, `session_id`, `created`, `status`, `response`) VALUES
(1, 'G-19887', 'Michele', '45378341', '2022-08-22 11:21:11', 0, 'Your Order (45378341) is being processed.'),
(2, 'G-19887', 'Georgianna', '518998796', '2022-08-22 11:22:03', 0, 'Your Order (518998796) is being processed.'),
(3, 'G-19887', 'Joan', '2095215544', '2022-08-22 11:22:57', 0, 'Your Order (2095215544) is being processed.'),
(4, 'G-19887', 'Tyisha', '2074568426', '2022-08-22 12:01:06', 0, 'Your Order (2074568426) is being processed.'),
(5, 'G-19887', 'Elida', '1959911712', '2022-08-22 12:01:12', 0, 'Your Order (1959911712) is being processed.'),
(6, 'G-19887', 'Rebecka', '336768871', '2022-08-22 12:14:02', 0, 'Your Order (336768871) is being processed.'),
(7, 'G-19887', 'Margherita', '1845075944', '2022-08-22 12:25:07', 0, 'Your Order (1845075944) is being processed.'),
(8, 'G-19887', 'Qiana', '91609067', '2022-08-22 12:26:40', 0, 'Your Order (91609067) is being processed.'),
(9, 'G-19887', 'Jeanice', '859774196', '2022-08-22 12:27:47', 0, 'Your Order (859774196) is being processed.'),
(10, 'G-19887', 'Lloyd', '482534075', '2022-08-22 12:43:23', 0, 'Your Order (482534075) is being processed.'),
(11, 'G-19887', 'Bong', '1329003324', '2022-08-22 12:44:31', 1, 'Your Order (1329003324) is being processed.'),
(12, 'G-19887', 'Joan', '1283427033', '2022-08-22 12:46:06', 1, 'Your Order (1283427033) is being processed.'),
(13, 'G-19887', 'Diego', '1582705662', '2022-08-22 12:46:09', 1, 'Your Order (1582705662) is being processed.'),
(14, 'G-19887', 'Margarett', '43023846', '2022-08-22 12:48:53', 1, 'Your Order (43023846) is being processed.'),
(15, 'G-19887', 'Laine', '1450312798', '2022-08-22 13:37:11', 1, 'Your Order (1450312798) is being processed.'),
(16, 'G-19887', 'Clora', '1592176738', '2022-08-22 13:49:23', 1, 'Your Order (1592176738) is being processed.'),
(17, 'G-19887', 'Laine', '1576042249', '2022-08-22 13:52:01', 1, 'Your Order (1576042249) is being processed.'),
(18, 'G-19887', 'Buffy', '1866879438', '2022-08-22 15:19:16', 1, 'Your Order (1866879438) is being processed.');

-- --------------------------------------------------------

--
-- Table structure for table `trans_global_settings`
--

CREATE TABLE `trans_global_settings` (
  `global_val_id` int(11) NOT NULL,
  `global_name_id` int(11) DEFAULT NULL,
  `value` varchar(1000) DEFAULT NULL,
  `lang_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trans_global_settings`
--

INSERT INTO `trans_global_settings` (`global_val_id`, `global_name_id`, `value`, `lang_id`) VALUES
(1, 1, 'astrology@callidustechno.com', 17),
(2, 2, 'Astrovani', 17),
(6, 3, 'pawan.kanherkar@callidustechno.com', 17),
(8, 4, 'Y/m/d', 17),
(14, 7, '10', 17),
(15, 8, 'http://www.facebook.com/', 17),
(16, 9, 'http://twitter.com/', 17),
(18, 11, 'http://plus.google.com/', 17),
(20, 13, '02064656565', 17),
(21, 14, '747764141969929', 17),
(22, 15, 'http://www.pinterest.com', 17),
(23, 16, '412301', 17),
(24, 17, 'Queen Square56 College Green RoadBS1 XR18Bristol, UK ', 17),
(25, 18, 'street', 17),
(26, 19, 'pune', 17),
(27, 20, 'Lorem Ipsum Is Simply Dummy Text Of The Printing And Typesetting Industry. Lorem Ipsum Has Been The Industry\'s Standard Dummy Text Ever Since The 1500s', 17),
(28, 1, 'sofia111@panaceatek.com', 12),
(29, 2, '調整 調整 調整 調整', 12),
(30, 4, 'Y-m-d H:i:s', 12),
(31, 7, '1', 12),
(32, 8, 'http://調整.in', 12),
(33, 20, '調整 調整 調整 調整 調整 調整 調整 調整 調整 調整 調整', 12),
(34, 17, '調整調整調整調整調整 調整 調整調整調整調整調整調整調整調整', 12),
(35, 19, '調整 調整 調整 調整 調整 調整 調整 調整 調整', 12),
(36, 18, '調整 調整 調整 調整 調整 調整 調整 調整 調整', 12);

-- --------------------------------------------------------

--
-- Table structure for table `trans_role_privileges`
--

CREATE TABLE `trans_role_privileges` (
  `role_privilege_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `privilege_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trans_role_privileges`
--

INSERT INTO `trans_role_privileges` (`role_privilege_id`, `role_id`, `privilege_id`) VALUES
(293, 25, 1),
(294, 25, 2),
(295, 25, 3),
(322, 24, 1),
(323, 24, 3),
(324, 24, 4),
(325, 24, 5),
(326, 24, 6),
(327, 24, 7),
(333, 24, 3),
(334, 24, 4),
(335, 24, 5),
(336, 25, 1),
(337, 25, 3),
(338, 24, 1),
(339, 24, 3),
(340, 24, 4),
(351, 30, 1),
(352, 30, 3),
(358, 32, 7),
(359, 32, 8),
(360, 33, 8),
(361, 34, 8),
(362, 35, 8),
(384, 31, 1),
(385, 31, 3),
(391, 37, 7),
(392, 37, 8),
(393, 38, 8),
(394, 23, 1),
(395, 23, 3),
(396, 23, 7),
(397, 39, 4),
(398, 39, 5),
(399, 40, 1),
(400, 40, 3),
(401, 41, 1),
(402, 41, 3),
(403, 42, 7),
(404, 42, 8),
(405, 36, 1),
(406, 36, 3),
(407, 36, 4),
(408, 36, 5),
(409, 36, 6),
(410, 36, 7),
(411, 36, 8);

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `user_id` int(11) NOT NULL,
  `id_num` varchar(255) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `dob` varchar(20) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `medical_history` varchar(255) DEFAULT NULL,
  `admission_date` varchar(100) DEFAULT NULL,
  `admiss_exp_date` varchar(100) DEFAULT NULL,
  `total_amount` int(11) DEFAULT NULL,
  `free_steam` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `plan_id` int(11) DEFAULT NULL,
  `admission_fees` varchar(100) DEFAULT NULL,
  `duration_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`user_id`, `id_num`, `name`, `mobile_no`, `dob`, `profile_image`, `address`, `medical_history`, `admission_date`, `admiss_exp_date`, `total_amount`, `free_steam`, `status`, `plan_id`, `admission_fees`, `duration_id`) VALUES
(1, '111', 'Rohit Patil ', '1111111111', '2059-11-30', NULL, 'Khadkpada,Kalyan', 'NIll', '2017-02-21', '2019-03-31', NULL, 15, NULL, 2, '500', 4),
(2, NULL, 'Sunil Patil', '9588454255', '2000-06-14', NULL, 'Kalyan ', 'Nill', '2019-02-21', '2019-03-28', NULL, 5, NULL, 1, '200', 1),
(3, NULL, 'Rohan Kulkarni', '9766454255', '1996-06-12', '1550760964.jpg', 'Thane', 'NIll', '2019-02-21', '2019-03-28', NULL, 5, NULL, 1, '200', 2),
(4, NULL, 'Sunil Patil ', '8605422781', '2004-06-16', '1551279315.jpg', 'Khadkpad kalyan ', 'NILL', '2019-02-15', '2019-03-21', NULL, 5, NULL, 2, '100', 2),
(5, NULL, 'Amar Yelmar', '8208091007', '2018-11-16', '1551280052.jpg', 'Khadkpada Kalyan', 'NILL', '2019-01-24', '2019-02-28', NULL, 5, NULL, 2, '500', 2),
(6, NULL, 'test test', '8208091007', '2019-02-13', '1551280350.jpg', 'test', 'test', '2019-02-20', '2019-02-19', NULL, 5, NULL, 2, 'test', 2),
(7, NULL, 'Sagar Kure ', '8652256195', '2019-02-05', '1551280453.png', 'test', 'testest', '2019-02-05', '2019-02-06', NULL, 5, NULL, 2, '500', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `last_activity_idx` (`last_activity`);

--
-- Indexes for table `duration`
--
ALTER TABLE `duration`
  ADD PRIMARY KEY (`duration_id`);

--
-- Indexes for table `manage_user_plan`
--
ALTER TABLE `manage_user_plan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mst_employees`
--
ALTER TABLE `mst_employees`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `tbl_user_request`
--
ALTER TABLE `tbl_user_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trans_global_settings`
--
ALTER TABLE `trans_global_settings`
  ADD PRIMARY KEY (`global_val_id`),
  ADD KEY `language_fk_genral` (`lang_id`),
  ADD KEY `global_id` (`global_name_id`);

--
-- Indexes for table `trans_role_privileges`
--
ALTER TABLE `trans_role_privileges`
  ADD PRIMARY KEY (`role_privilege_id`),
  ADD KEY `fk_Role_id` (`role_id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `duration`
--
ALTER TABLE `duration`
  MODIFY `duration_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `manage_user_plan`
--
ALTER TABLE `manage_user_plan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mst_employees`
--
ALTER TABLE `mst_employees`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_user_request`
--
ALTER TABLE `tbl_user_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `trans_global_settings`
--
ALTER TABLE `trans_global_settings`
  MODIFY `global_val_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `trans_role_privileges`
--
ALTER TABLE `trans_role_privileges`
  MODIFY `role_privilege_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=412;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
