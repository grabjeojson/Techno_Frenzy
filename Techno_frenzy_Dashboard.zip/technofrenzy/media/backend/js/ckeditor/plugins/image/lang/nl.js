﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'nl', {
	alertUrl: 'Geef de URL van de afbeelding',
	alt: 'Alternatieve tekst',
	border: 'Rand',
	btnUpload: 'Naar server verzenden',
	button2Img: 'Wilt u de geselecteerde afbeeldingsknop vervangen door een eenvoudige afbeelding?',
	hSpace: 'HSpace',
	img2Button: 'Wilt u de geselecteerde afbeelding vervangen door een afbeeldingsknop?',
	infoTab: 'Informatie afbeelding',
	linkTab: 'Link',
	lockRatio: 'Afmetingen vergrendelen',
	menu: 'Eigenschappen afbeelding',
	resetSize: 'Afmetingen resetten',
	title: 'Eigenschappen afbeelding',
	titleButton: 'Eigenschappen afbeeldingsknop',
	upload: 'Upload',
	urlMissing: 'De URL naar de afbeelding ontbreekt.',
	vSpace: 'VSpace',
	validateBorder: 'Rand moet een heel nummer zijn.',
	validateHSpace: 'HSpace moet een heel nummer zijn.',
	validateVSpace: 'VSpace moet een heel nummer zijn.'
} );
