// JavaScript Document
$(document).ready(function(e) {        
	$("#frm_user_details").validate({
		errorElement: "div",
		rules: {
			name:{
				required:true,
                notNumber:true
			},
			mobile_no:{
				required:true,
                minlength: 10,
                notChar:true
			},
			user_name:{
				required:true,
				chk_username_field:true,
				remote:{
					url: jQuery("#base_url").val()+"backend/revision-2-at/admin/check-admin-username",
					type: "post"
				}
			},
			email_id:{
				required:true,
				email:true,
				// remote:{
				// 	url: jQuery("#base_url").val()+"backend/revision-2-at/admin/check-admin-email",	
				// 	type: "post"
				// }
			},
			password:{
				 required: true,
				 minlength: 5,
				 maxlength:15,
				 //password_strenth: true
			},
			
			role_id:{
				required:true	
			},
			address:{
				required:true	
			},
			about_org:{
				required:true	
			},
			// city:{
			// 	required:true	
			// }


		},
		messages:{
			name:{
				required:"Please enter name.",
                notNumber:"Please enter valid name."
			},
			/*last_name:{
				required:"Please enter last name.",
                notNumber:"Please enter valid name."
			},*/
			mobile_no:{
				number:"Please enter valid mobile number.",
				minlength:"Please enter 10 digit mobile number"
			},
			user_name:{
				required:"Please enter username.",
				chk_username_field:"Please enter a valid username. It must contain 5-20 characters. Characters other than <b> A-Z, a-z, 0-9, _ , . , - </b>  are not allowed.",
				remote:"Username already exists."
			},
			email:{
				required:"Please enter an email address.",
				email:"Please enter a valid email address.",
				remote:"Email address already exists."
			},
			password:{
				required: "Please enter password.",
                minlength: "Please enter atleast 5 to 15 characters."

			},
			
			role_id:{
				required:"Please select admin user role."
			},
			address:{
				required:"Please enter an address."
			},
			about_org:{
				required:"Please enter about organization."
			},
			// city:{
			// 	required:"Please select city."
			// }

		},
		submitHandler: function (form) {
         	 $("#btnSubmit").hide();
            $('#loding_image').show();
            form.submit();
        }
	});
	jQuery.validator.addMethod("notNumber", function(value, element, param) {
                       var reg = /^[0-9]/;
                       if(reg.test(value)){
                             return false;
                       }else{
                               return true;
                       }
                }, "Number is not permitted");

	jQuery.validator.addMethod("notChar", function(value, element, param) {
                       var reg = /^[a-zA-Z-._-]/;
                       if(reg.test(value)){
                             return false;
                       }else{
                               return true;
                       }
                }, "Characters is not permitted");
	jQuery.validator.addMethod('chk_username_field', function(value, element, param) {
		 if ( value.match('^[0-9a-zA-Z-._-]{5,20}$') ) {
			return true;
		} else {
			 return false;
		}
		
	},"");
	
	jQuery.validator.addMethod("password_strenth", function(value, element) {
		return isPasswordStrong(value, element);
	}, "Password must be strong");
	
	$("#check_box").css({display:"block",opacity:"0",height:"0",width:"0","float":"right"});
});