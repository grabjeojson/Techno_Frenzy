<?php 
$link = mysqli_connect("localhost", "skssickoiripatt_technofrenzy", "an2QDCITGv","skssickoiripatt_technofrenzy");
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

if ($result = mysqli_query($link, "SELECT * FROM tbl_user_request where response!=''")) {
  if ($result->num_rows > 0) {
    	while($row = $result->fetch_assoc()) {
      		$orderResponse= $row["response"];              
   		}
    echo '[{"responseData":{"erroCode":"0","errorDesc":"'.$orderResponse.'"}}]';
  }else {
    echo '[{"responseData":{"erroCode":"4","errorDesc":"No Ordes Found. Please try for another Order."}}]';
  }  
  
}else {
   echo '[{"responseData":{"erroCode":"4","errorDesc":"Please try again."}}]';
}  
mysqli_close($link);
exit;
?>